﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CW_5
{
    public partial class Form1 : Form
    {
        DataTable dataMatch = new DataTable("Match");
        DataSet dataset_Match = new DataSet();
        string[] team_name = { "Chicago Bulls", "Cleveland Cavalier", "Detroit Pistons", "Indiana Pacers", "Milwauke Bucks", "Boston Celtics", "Brooklyn Nets", "New York Knicks", "Philadelphia", "Toronto Rapto" };
        int selected_row = -1;
        string home, away;

        public void InitialData()
        {
            DataColumn dtColumn;
            DataRow myDataRow;

            dtColumn = new DataColumn
            {
                DataType = typeof(string),
                ColumnName = "Date",
                ReadOnly = false
            };
            dataMatch.Columns.Add(dtColumn);

            dtColumn = new DataColumn
            {
                DataType = typeof(string),
                ColumnName = "Home Team Name",
                ReadOnly = false
            };
            dataMatch.Columns.Add(dtColumn);

            dtColumn = new DataColumn
            {
                DataType = typeof(Int32),
                ColumnName = "Home Score",
                ReadOnly = false
            };
            dataMatch.Columns.Add(dtColumn);

            dtColumn = new DataColumn
            {
                DataType = typeof(Int32),
                ColumnName = "Away Score",
                ReadOnly = false
            };
            dataMatch.Columns.Add(dtColumn);

            dtColumn = new DataColumn
            {
                DataType = typeof(string),
                ColumnName = "Away Team Name",
                ReadOnly = false
            };
            dataMatch.Columns.Add(dtColumn);
            for (int i = 0; i < team_name.Count(); i++)
            {
                comboBox1.Items.Add(team_name[i]);
                comboBox2.Items.Add(team_name[i]);
            }
        }
        public Form1()
        {
            InitializeComponent();
            InitialData();
            dataGridView1.DataSource = dataMatch;
        }

        public static DialogResult InputBox(string title, string promptText, ref string value)
        {
            Form form = new Form();
            Label label = new Label();
            System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox();
            System.Windows.Forms.Button buttonOk = new System.Windows.Forms.Button();
            System.Windows.Forms.Button buttonCancel = new System.Windows.Forms.Button();

            form.Text = title;
            label.Text = promptText;

            buttonOk.Text = "OK";
            buttonCancel.Text = "Cancel";
            buttonOk.DialogResult = DialogResult.OK;
            buttonCancel.DialogResult = DialogResult.Cancel;

            label.SetBounds(16, 10, 372, 13);
            textBox.SetBounds(16, 30, 700, 20);
            buttonOk.SetBounds(16, 70, 60, 30);
            buttonCancel.SetBounds(100, 70, 60, 30);

            label.AutoSize = true;
            form.ClientSize = new Size(200, 200);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;

            form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
            form.AcceptButton = buttonOk;
            form.CancelButton = buttonCancel;

            DialogResult dialogResult = form.ShowDialog();

            value = textBox.Text;
            return dialogResult;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((selected_row == -1))
            {
                string message = "Please select items!";
                MessageBox.Show(message);
            }
            else
            {
                if (selected_row < dataMatch.Rows.Count)
                    dataMatch.Rows[selected_row].Delete();
                else
                {
                    string message = "Please select items!";
                    MessageBox.Show(message);
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            selected_row = rowIndex;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // only accept number
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as System.Windows.Forms.TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            // only accept number
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as System.Windows.Forms.TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataRow myDataRow, myDataRow1;
            string tanggal = dateTimePicker1.Value.ToString();
            string hometeam_name = home;
            string awayteam_name = away;
            string homescore = textBox1.Text;
            string awayscore = textBox2.Text;
            if ((tanggal == "") || (hometeam_name == "") || (awayteam_name == "") || (homescore == "") || (awayscore == ""))
            {
                string message = "Please fill all field!";
                MessageBox.Show(message);
            }

            myDataRow = dataMatch.NewRow();
            myDataRow["Date"] = tanggal;
            myDataRow["Home Team Name"] = hometeam_name;
            myDataRow["Home Score"] = homescore;
            myDataRow["Away Score"] = awayscore;
            myDataRow["Away Team Name"] = awayteam_name;
            dataMatch.Rows.Add(myDataRow);
        }
        public void initCombobox(int comb)
        {
            if (comb == 1)
            {
                home = comboBox1.SelectedItem.ToString();
                comboBox2.Items.Clear();
                for (int i = 0; i < team_name.Count(); i++)
                {
                    if (comboBox1.SelectedItem.ToString() != team_name[i])
                        comboBox2.Items.Add(team_name[i]);
                }
            }
            else if (comb == 2)
            {
                away = comboBox2.SelectedItem.ToString();
                comboBox1.Items.Clear();
                for (int i = 0; i < team_name.Count(); i++)
                {
                    if (comboBox2.SelectedItem.ToString() != team_name[i])
                        comboBox1.Items.Add(team_name[i]);
                }
            }
        }
        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            initCombobox(1);
        }

        private void comboBox2_SelectedValueChanged(object sender, EventArgs e)
        {
            initCombobox(2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string value = "";
            if (InputBox("Dialog Box", "Enter a team name?", ref value) == DialogResult.OK)
            {
                var team_nameList = team_name.ToList();
                team_nameList.Add(value);
                team_name = team_nameList.ToArray();

                MessageBox.Show("Team " + value + " added");
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                for (int i = 0; i < team_name.Count(); i++)
                {
                    comboBox1.Items.Add(team_name[i]);
                    comboBox2.Items.Add(team_name[i]);
                }
            }
        }
    }
}
