﻿namespace WORDLE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.box0_0 = new System.Windows.Forms.TextBox();
            this.box0_1 = new System.Windows.Forms.TextBox();
            this.box0_2 = new System.Windows.Forms.TextBox();
            this.box0_3 = new System.Windows.Forms.TextBox();
            this.box0_4 = new System.Windows.Forms.TextBox();
            this.box1_0 = new System.Windows.Forms.TextBox();
            this.box1_1 = new System.Windows.Forms.TextBox();
            this.box1_2 = new System.Windows.Forms.TextBox();
            this.box1_3 = new System.Windows.Forms.TextBox();
            this.box1_4 = new System.Windows.Forms.TextBox();
            this.box2_4 = new System.Windows.Forms.TextBox();
            this.box2_3 = new System.Windows.Forms.TextBox();
            this.box2_2 = new System.Windows.Forms.TextBox();
            this.box2_1 = new System.Windows.Forms.TextBox();
            this.box2_0 = new System.Windows.Forms.TextBox();
            this.box3_4 = new System.Windows.Forms.TextBox();
            this.box3_3 = new System.Windows.Forms.TextBox();
            this.box3_2 = new System.Windows.Forms.TextBox();
            this.box3_1 = new System.Windows.Forms.TextBox();
            this.box3_0 = new System.Windows.Forms.TextBox();
            this.box4_4 = new System.Windows.Forms.TextBox();
            this.box4_3 = new System.Windows.Forms.TextBox();
            this.box4_2 = new System.Windows.Forms.TextBox();
            this.box4_1 = new System.Windows.Forms.TextBox();
            this.box4_0 = new System.Windows.Forms.TextBox();
            this.box5_4 = new System.Windows.Forms.TextBox();
            this.box5_3 = new System.Windows.Forms.TextBox();
            this.box5_2 = new System.Windows.Forms.TextBox();
            this.box5_1 = new System.Windows.Forms.TextBox();
            this.box5_0 = new System.Windows.Forms.TextBox();
            this.box6_4 = new System.Windows.Forms.TextBox();
            this.box6_3 = new System.Windows.Forms.TextBox();
            this.box6_2 = new System.Windows.Forms.TextBox();
            this.box6_1 = new System.Windows.Forms.TextBox();
            this.box6_0 = new System.Windows.Forms.TextBox();
            this.box7_4 = new System.Windows.Forms.TextBox();
            this.box7_3 = new System.Windows.Forms.TextBox();
            this.box7_2 = new System.Windows.Forms.TextBox();
            this.box7_1 = new System.Windows.Forms.TextBox();
            this.box7_0 = new System.Windows.Forms.TextBox();
            this.box8_4 = new System.Windows.Forms.TextBox();
            this.box8_3 = new System.Windows.Forms.TextBox();
            this.box8_2 = new System.Windows.Forms.TextBox();
            this.box8_1 = new System.Windows.Forms.TextBox();
            this.box8_0 = new System.Windows.Forms.TextBox();
            this.box9_4 = new System.Windows.Forms.TextBox();
            this.box9_3 = new System.Windows.Forms.TextBox();
            this.box9_2 = new System.Windows.Forms.TextBox();
            this.box9_1 = new System.Windows.Forms.TextBox();
            this.box9_0 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonQ = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.button_enter = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // box0_0
            // 
            this.box0_0.Enabled = false;
            this.box0_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box0_0.Location = new System.Drawing.Point(12, 12);
            this.box0_0.Name = "box0_0";
            this.box0_0.Size = new System.Drawing.Size(35, 30);
            this.box0_0.TabIndex = 0;
            this.box0_0.Text = "_";
            this.box0_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box0_1
            // 
            this.box0_1.Enabled = false;
            this.box0_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box0_1.Location = new System.Drawing.Point(53, 12);
            this.box0_1.Name = "box0_1";
            this.box0_1.Size = new System.Drawing.Size(35, 30);
            this.box0_1.TabIndex = 1;
            this.box0_1.Text = "_";
            this.box0_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box0_2
            // 
            this.box0_2.Enabled = false;
            this.box0_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box0_2.Location = new System.Drawing.Point(94, 12);
            this.box0_2.Name = "box0_2";
            this.box0_2.Size = new System.Drawing.Size(35, 30);
            this.box0_2.TabIndex = 2;
            this.box0_2.Text = "_";
            this.box0_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box0_3
            // 
            this.box0_3.Enabled = false;
            this.box0_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box0_3.Location = new System.Drawing.Point(135, 12);
            this.box0_3.Name = "box0_3";
            this.box0_3.Size = new System.Drawing.Size(35, 30);
            this.box0_3.TabIndex = 3;
            this.box0_3.Text = "_";
            this.box0_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box0_4
            // 
            this.box0_4.Enabled = false;
            this.box0_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box0_4.Location = new System.Drawing.Point(176, 12);
            this.box0_4.Name = "box0_4";
            this.box0_4.Size = new System.Drawing.Size(35, 30);
            this.box0_4.TabIndex = 4;
            this.box0_4.Text = "_";
            this.box0_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box1_0
            // 
            this.box1_0.Enabled = false;
            this.box1_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box1_0.Location = new System.Drawing.Point(12, 60);
            this.box1_0.Name = "box1_0";
            this.box1_0.Size = new System.Drawing.Size(35, 30);
            this.box1_0.TabIndex = 5;
            this.box1_0.Text = "_";
            this.box1_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box1_1
            // 
            this.box1_1.Enabled = false;
            this.box1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box1_1.Location = new System.Drawing.Point(53, 60);
            this.box1_1.Name = "box1_1";
            this.box1_1.Size = new System.Drawing.Size(35, 30);
            this.box1_1.TabIndex = 6;
            this.box1_1.Text = "_";
            this.box1_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box1_2
            // 
            this.box1_2.Enabled = false;
            this.box1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box1_2.Location = new System.Drawing.Point(94, 60);
            this.box1_2.Name = "box1_2";
            this.box1_2.Size = new System.Drawing.Size(35, 30);
            this.box1_2.TabIndex = 7;
            this.box1_2.Text = "_";
            this.box1_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box1_3
            // 
            this.box1_3.Enabled = false;
            this.box1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box1_3.Location = new System.Drawing.Point(135, 60);
            this.box1_3.Name = "box1_3";
            this.box1_3.Size = new System.Drawing.Size(35, 30);
            this.box1_3.TabIndex = 8;
            this.box1_3.Text = "_";
            this.box1_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box1_4
            // 
            this.box1_4.Enabled = false;
            this.box1_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box1_4.Location = new System.Drawing.Point(176, 60);
            this.box1_4.Name = "box1_4";
            this.box1_4.Size = new System.Drawing.Size(35, 30);
            this.box1_4.TabIndex = 9;
            this.box1_4.Text = "_";
            this.box1_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box2_4
            // 
            this.box2_4.Enabled = false;
            this.box2_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box2_4.Location = new System.Drawing.Point(176, 106);
            this.box2_4.Name = "box2_4";
            this.box2_4.Size = new System.Drawing.Size(35, 30);
            this.box2_4.TabIndex = 14;
            this.box2_4.Text = "_";
            this.box2_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box2_3
            // 
            this.box2_3.Enabled = false;
            this.box2_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box2_3.Location = new System.Drawing.Point(135, 106);
            this.box2_3.Name = "box2_3";
            this.box2_3.Size = new System.Drawing.Size(35, 30);
            this.box2_3.TabIndex = 13;
            this.box2_3.Text = "_";
            this.box2_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box2_2
            // 
            this.box2_2.Enabled = false;
            this.box2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box2_2.Location = new System.Drawing.Point(94, 106);
            this.box2_2.Name = "box2_2";
            this.box2_2.Size = new System.Drawing.Size(35, 30);
            this.box2_2.TabIndex = 12;
            this.box2_2.Text = "_";
            this.box2_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box2_1
            // 
            this.box2_1.Enabled = false;
            this.box2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box2_1.Location = new System.Drawing.Point(53, 106);
            this.box2_1.Name = "box2_1";
            this.box2_1.Size = new System.Drawing.Size(35, 30);
            this.box2_1.TabIndex = 11;
            this.box2_1.Text = "_";
            this.box2_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box2_0
            // 
            this.box2_0.Enabled = false;
            this.box2_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box2_0.Location = new System.Drawing.Point(12, 106);
            this.box2_0.Name = "box2_0";
            this.box2_0.Size = new System.Drawing.Size(35, 30);
            this.box2_0.TabIndex = 10;
            this.box2_0.Text = "_";
            this.box2_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box3_4
            // 
            this.box3_4.Enabled = false;
            this.box3_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box3_4.Location = new System.Drawing.Point(176, 152);
            this.box3_4.Name = "box3_4";
            this.box3_4.Size = new System.Drawing.Size(35, 30);
            this.box3_4.TabIndex = 19;
            this.box3_4.Text = "_";
            this.box3_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box3_3
            // 
            this.box3_3.Enabled = false;
            this.box3_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box3_3.Location = new System.Drawing.Point(135, 152);
            this.box3_3.Name = "box3_3";
            this.box3_3.Size = new System.Drawing.Size(35, 30);
            this.box3_3.TabIndex = 18;
            this.box3_3.Text = "_";
            this.box3_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box3_2
            // 
            this.box3_2.Enabled = false;
            this.box3_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box3_2.Location = new System.Drawing.Point(94, 152);
            this.box3_2.Name = "box3_2";
            this.box3_2.Size = new System.Drawing.Size(35, 30);
            this.box3_2.TabIndex = 17;
            this.box3_2.Text = "_";
            this.box3_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box3_1
            // 
            this.box3_1.Enabled = false;
            this.box3_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box3_1.Location = new System.Drawing.Point(53, 152);
            this.box3_1.Name = "box3_1";
            this.box3_1.Size = new System.Drawing.Size(35, 30);
            this.box3_1.TabIndex = 16;
            this.box3_1.Text = "_";
            this.box3_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box3_0
            // 
            this.box3_0.Enabled = false;
            this.box3_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box3_0.Location = new System.Drawing.Point(12, 152);
            this.box3_0.Name = "box3_0";
            this.box3_0.Size = new System.Drawing.Size(35, 30);
            this.box3_0.TabIndex = 15;
            this.box3_0.Text = "_";
            this.box3_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box4_4
            // 
            this.box4_4.Enabled = false;
            this.box4_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box4_4.Location = new System.Drawing.Point(176, 198);
            this.box4_4.Name = "box4_4";
            this.box4_4.Size = new System.Drawing.Size(35, 30);
            this.box4_4.TabIndex = 24;
            this.box4_4.Text = "_";
            this.box4_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box4_3
            // 
            this.box4_3.Enabled = false;
            this.box4_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box4_3.Location = new System.Drawing.Point(135, 198);
            this.box4_3.Name = "box4_3";
            this.box4_3.Size = new System.Drawing.Size(35, 30);
            this.box4_3.TabIndex = 23;
            this.box4_3.Text = "_";
            this.box4_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box4_2
            // 
            this.box4_2.Enabled = false;
            this.box4_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box4_2.Location = new System.Drawing.Point(94, 198);
            this.box4_2.Name = "box4_2";
            this.box4_2.Size = new System.Drawing.Size(35, 30);
            this.box4_2.TabIndex = 22;
            this.box4_2.Text = "_";
            this.box4_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box4_1
            // 
            this.box4_1.Enabled = false;
            this.box4_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box4_1.Location = new System.Drawing.Point(53, 198);
            this.box4_1.Name = "box4_1";
            this.box4_1.Size = new System.Drawing.Size(35, 30);
            this.box4_1.TabIndex = 21;
            this.box4_1.Text = "_";
            this.box4_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box4_0
            // 
            this.box4_0.Enabled = false;
            this.box4_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box4_0.Location = new System.Drawing.Point(12, 198);
            this.box4_0.Name = "box4_0";
            this.box4_0.Size = new System.Drawing.Size(35, 30);
            this.box4_0.TabIndex = 20;
            this.box4_0.Text = "_";
            this.box4_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box5_4
            // 
            this.box5_4.Enabled = false;
            this.box5_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box5_4.Location = new System.Drawing.Point(176, 244);
            this.box5_4.Name = "box5_4";
            this.box5_4.Size = new System.Drawing.Size(35, 30);
            this.box5_4.TabIndex = 29;
            this.box5_4.Text = "_";
            this.box5_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box5_3
            // 
            this.box5_3.Enabled = false;
            this.box5_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box5_3.Location = new System.Drawing.Point(135, 244);
            this.box5_3.Name = "box5_3";
            this.box5_3.Size = new System.Drawing.Size(35, 30);
            this.box5_3.TabIndex = 28;
            this.box5_3.Text = "_";
            this.box5_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box5_2
            // 
            this.box5_2.Enabled = false;
            this.box5_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box5_2.Location = new System.Drawing.Point(94, 244);
            this.box5_2.Name = "box5_2";
            this.box5_2.Size = new System.Drawing.Size(35, 30);
            this.box5_2.TabIndex = 27;
            this.box5_2.Text = "_";
            this.box5_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box5_1
            // 
            this.box5_1.Enabled = false;
            this.box5_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box5_1.Location = new System.Drawing.Point(53, 244);
            this.box5_1.Name = "box5_1";
            this.box5_1.Size = new System.Drawing.Size(35, 30);
            this.box5_1.TabIndex = 26;
            this.box5_1.Text = "_";
            this.box5_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box5_0
            // 
            this.box5_0.Enabled = false;
            this.box5_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box5_0.Location = new System.Drawing.Point(12, 244);
            this.box5_0.Name = "box5_0";
            this.box5_0.Size = new System.Drawing.Size(35, 30);
            this.box5_0.TabIndex = 25;
            this.box5_0.Text = "_";
            this.box5_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box6_4
            // 
            this.box6_4.Enabled = false;
            this.box6_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box6_4.Location = new System.Drawing.Point(176, 289);
            this.box6_4.Name = "box6_4";
            this.box6_4.Size = new System.Drawing.Size(35, 30);
            this.box6_4.TabIndex = 34;
            this.box6_4.Text = "_";
            this.box6_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box6_3
            // 
            this.box6_3.Enabled = false;
            this.box6_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box6_3.Location = new System.Drawing.Point(135, 289);
            this.box6_3.Name = "box6_3";
            this.box6_3.Size = new System.Drawing.Size(35, 30);
            this.box6_3.TabIndex = 33;
            this.box6_3.Text = "_";
            this.box6_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box6_2
            // 
            this.box6_2.Enabled = false;
            this.box6_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box6_2.Location = new System.Drawing.Point(94, 289);
            this.box6_2.Name = "box6_2";
            this.box6_2.Size = new System.Drawing.Size(35, 30);
            this.box6_2.TabIndex = 32;
            this.box6_2.Text = "_";
            this.box6_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box6_1
            // 
            this.box6_1.Enabled = false;
            this.box6_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box6_1.Location = new System.Drawing.Point(53, 289);
            this.box6_1.Name = "box6_1";
            this.box6_1.Size = new System.Drawing.Size(35, 30);
            this.box6_1.TabIndex = 31;
            this.box6_1.Text = "_";
            this.box6_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box6_0
            // 
            this.box6_0.Enabled = false;
            this.box6_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box6_0.Location = new System.Drawing.Point(12, 289);
            this.box6_0.Name = "box6_0";
            this.box6_0.Size = new System.Drawing.Size(35, 30);
            this.box6_0.TabIndex = 30;
            this.box6_0.Text = "_";
            this.box6_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box7_4
            // 
            this.box7_4.Enabled = false;
            this.box7_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box7_4.Location = new System.Drawing.Point(176, 334);
            this.box7_4.Name = "box7_4";
            this.box7_4.Size = new System.Drawing.Size(35, 30);
            this.box7_4.TabIndex = 39;
            this.box7_4.Text = "_";
            this.box7_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box7_3
            // 
            this.box7_3.Enabled = false;
            this.box7_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box7_3.Location = new System.Drawing.Point(135, 334);
            this.box7_3.Name = "box7_3";
            this.box7_3.Size = new System.Drawing.Size(35, 30);
            this.box7_3.TabIndex = 38;
            this.box7_3.Text = "_";
            this.box7_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box7_2
            // 
            this.box7_2.Enabled = false;
            this.box7_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box7_2.Location = new System.Drawing.Point(94, 334);
            this.box7_2.Name = "box7_2";
            this.box7_2.Size = new System.Drawing.Size(35, 30);
            this.box7_2.TabIndex = 37;
            this.box7_2.Text = "_";
            this.box7_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box7_1
            // 
            this.box7_1.Enabled = false;
            this.box7_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box7_1.Location = new System.Drawing.Point(53, 334);
            this.box7_1.Name = "box7_1";
            this.box7_1.Size = new System.Drawing.Size(35, 30);
            this.box7_1.TabIndex = 36;
            this.box7_1.Text = "_";
            this.box7_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box7_0
            // 
            this.box7_0.Enabled = false;
            this.box7_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box7_0.Location = new System.Drawing.Point(12, 334);
            this.box7_0.Name = "box7_0";
            this.box7_0.Size = new System.Drawing.Size(35, 30);
            this.box7_0.TabIndex = 35;
            this.box7_0.Text = "_";
            this.box7_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box8_4
            // 
            this.box8_4.Enabled = false;
            this.box8_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box8_4.Location = new System.Drawing.Point(176, 380);
            this.box8_4.Name = "box8_4";
            this.box8_4.Size = new System.Drawing.Size(35, 30);
            this.box8_4.TabIndex = 44;
            this.box8_4.Text = "_";
            this.box8_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box8_3
            // 
            this.box8_3.Enabled = false;
            this.box8_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box8_3.Location = new System.Drawing.Point(135, 380);
            this.box8_3.Name = "box8_3";
            this.box8_3.Size = new System.Drawing.Size(35, 30);
            this.box8_3.TabIndex = 43;
            this.box8_3.Text = "_";
            this.box8_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box8_2
            // 
            this.box8_2.Enabled = false;
            this.box8_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box8_2.Location = new System.Drawing.Point(94, 380);
            this.box8_2.Name = "box8_2";
            this.box8_2.Size = new System.Drawing.Size(35, 30);
            this.box8_2.TabIndex = 42;
            this.box8_2.Text = "_";
            this.box8_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box8_1
            // 
            this.box8_1.Enabled = false;
            this.box8_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box8_1.Location = new System.Drawing.Point(53, 380);
            this.box8_1.Name = "box8_1";
            this.box8_1.Size = new System.Drawing.Size(35, 30);
            this.box8_1.TabIndex = 41;
            this.box8_1.Text = "_";
            this.box8_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box8_0
            // 
            this.box8_0.Enabled = false;
            this.box8_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box8_0.Location = new System.Drawing.Point(12, 380);
            this.box8_0.Name = "box8_0";
            this.box8_0.Size = new System.Drawing.Size(35, 30);
            this.box8_0.TabIndex = 40;
            this.box8_0.Text = "_";
            this.box8_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box9_4
            // 
            this.box9_4.Enabled = false;
            this.box9_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box9_4.Location = new System.Drawing.Point(176, 428);
            this.box9_4.Name = "box9_4";
            this.box9_4.Size = new System.Drawing.Size(35, 30);
            this.box9_4.TabIndex = 49;
            this.box9_4.Text = "_";
            this.box9_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box9_3
            // 
            this.box9_3.Enabled = false;
            this.box9_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box9_3.Location = new System.Drawing.Point(135, 428);
            this.box9_3.Name = "box9_3";
            this.box9_3.Size = new System.Drawing.Size(35, 30);
            this.box9_3.TabIndex = 48;
            this.box9_3.Text = "_";
            this.box9_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box9_2
            // 
            this.box9_2.Enabled = false;
            this.box9_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box9_2.Location = new System.Drawing.Point(94, 428);
            this.box9_2.Name = "box9_2";
            this.box9_2.Size = new System.Drawing.Size(35, 30);
            this.box9_2.TabIndex = 47;
            this.box9_2.Text = "_";
            this.box9_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box9_1
            // 
            this.box9_1.Enabled = false;
            this.box9_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box9_1.Location = new System.Drawing.Point(53, 428);
            this.box9_1.Name = "box9_1";
            this.box9_1.Size = new System.Drawing.Size(35, 30);
            this.box9_1.TabIndex = 46;
            this.box9_1.Text = "_";
            this.box9_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // box9_0
            // 
            this.box9_0.Enabled = false;
            this.box9_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box9_0.Location = new System.Drawing.Point(12, 428);
            this.box9_0.Name = "box9_0";
            this.box9_0.Size = new System.Drawing.Size(35, 30);
            this.box9_0.TabIndex = 45;
            this.box9_0.Text = "_";
            this.box9_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.button_enter);
            this.panel1.Controls.Add(this.buttonM);
            this.panel1.Controls.Add(this.buttonZ);
            this.panel1.Controls.Add(this.buttonN);
            this.panel1.Controls.Add(this.buttonB);
            this.panel1.Controls.Add(this.buttonX);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.buttonC);
            this.panel1.Controls.Add(this.button_delete);
            this.panel1.Controls.Add(this.buttonS);
            this.panel1.Controls.Add(this.buttonA);
            this.panel1.Controls.Add(this.buttonL);
            this.panel1.Controls.Add(this.buttonK);
            this.panel1.Controls.Add(this.buttonD);
            this.panel1.Controls.Add(this.buttonJ);
            this.panel1.Controls.Add(this.buttonH);
            this.panel1.Controls.Add(this.buttonF);
            this.panel1.Controls.Add(this.buttonG);
            this.panel1.Controls.Add(this.buttonP);
            this.panel1.Controls.Add(this.buttonO);
            this.panel1.Controls.Add(this.buttonI);
            this.panel1.Controls.Add(this.buttonU);
            this.panel1.Controls.Add(this.buttonY);
            this.panel1.Controls.Add(this.buttonT);
            this.panel1.Controls.Add(this.buttonR);
            this.panel1.Controls.Add(this.buttonE);
            this.panel1.Controls.Add(this.buttonW);
            this.panel1.Controls.Add(this.buttonQ);
            this.panel1.Location = new System.Drawing.Point(255, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(698, 189);
            this.panel1.TabIndex = 50;
            // 
            // buttonQ
            // 
            this.buttonQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQ.Location = new System.Drawing.Point(16, 15);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(61, 50);
            this.buttonQ.TabIndex = 0;
            this.buttonQ.Text = "Q";
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.buttonQ_Click);
            // 
            // buttonW
            // 
            this.buttonW.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonW.Location = new System.Drawing.Point(83, 15);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(61, 50);
            this.buttonW.TabIndex = 1;
            this.buttonW.Text = "W";
            this.buttonW.UseVisualStyleBackColor = true;
            this.buttonW.Click += new System.EventHandler(this.buttonW_Click);
            // 
            // buttonE
            // 
            this.buttonE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.Location = new System.Drawing.Point(150, 15);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(61, 50);
            this.buttonE.TabIndex = 2;
            this.buttonE.Text = "E";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonR
            // 
            this.buttonR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonR.Location = new System.Drawing.Point(217, 15);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(61, 50);
            this.buttonR.TabIndex = 3;
            this.buttonR.Text = "R";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // buttonT
            // 
            this.buttonT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonT.Location = new System.Drawing.Point(284, 15);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(61, 50);
            this.buttonT.TabIndex = 4;
            this.buttonT.Text = "T";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonY
            // 
            this.buttonY.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonY.Location = new System.Drawing.Point(351, 15);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(61, 50);
            this.buttonY.TabIndex = 5;
            this.buttonY.Text = "Y";
            this.buttonY.UseVisualStyleBackColor = true;
            this.buttonY.Click += new System.EventHandler(this.buttonY_Click);
            // 
            // buttonU
            // 
            this.buttonU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonU.Location = new System.Drawing.Point(418, 15);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(61, 50);
            this.buttonU.TabIndex = 6;
            this.buttonU.Text = "U";
            this.buttonU.UseVisualStyleBackColor = true;
            this.buttonU.Click += new System.EventHandler(this.buttonU_Click);
            // 
            // buttonI
            // 
            this.buttonI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonI.Location = new System.Drawing.Point(485, 15);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(61, 50);
            this.buttonI.TabIndex = 7;
            this.buttonI.Text = "I";
            this.buttonI.UseVisualStyleBackColor = true;
            this.buttonI.Click += new System.EventHandler(this.buttonI_Click);
            // 
            // buttonO
            // 
            this.buttonO.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonO.Location = new System.Drawing.Point(552, 15);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(61, 50);
            this.buttonO.TabIndex = 8;
            this.buttonO.Text = "O";
            this.buttonO.UseVisualStyleBackColor = true;
            this.buttonO.Click += new System.EventHandler(this.buttonO_Click);
            // 
            // buttonP
            // 
            this.buttonP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonP.Location = new System.Drawing.Point(619, 15);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(61, 50);
            this.buttonP.TabIndex = 9;
            this.buttonP.Text = "P";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // buttonG
            // 
            this.buttonG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonG.Location = new System.Drawing.Point(321, 71);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(61, 50);
            this.buttonG.TabIndex = 10;
            this.buttonG.Text = "G";
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // buttonF
            // 
            this.buttonF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonF.Location = new System.Drawing.Point(254, 71);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(61, 50);
            this.buttonF.TabIndex = 11;
            this.buttonF.Text = "F";
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonH
            // 
            this.buttonH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonH.Location = new System.Drawing.Point(388, 71);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(61, 50);
            this.buttonH.TabIndex = 12;
            this.buttonH.Text = "H";
            this.buttonH.UseVisualStyleBackColor = true;
            this.buttonH.Click += new System.EventHandler(this.buttonH_Click);
            // 
            // buttonJ
            // 
            this.buttonJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJ.Location = new System.Drawing.Point(455, 71);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(61, 50);
            this.buttonJ.TabIndex = 13;
            this.buttonJ.Text = "J";
            this.buttonJ.UseVisualStyleBackColor = true;
            this.buttonJ.Click += new System.EventHandler(this.buttonJ_Click);
            // 
            // buttonD
            // 
            this.buttonD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonD.Location = new System.Drawing.Point(187, 71);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(61, 50);
            this.buttonD.TabIndex = 14;
            this.buttonD.Text = "D";
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // buttonK
            // 
            this.buttonK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonK.Location = new System.Drawing.Point(522, 71);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(74, 50);
            this.buttonK.TabIndex = 15;
            this.buttonK.Text = "K";
            this.buttonK.UseVisualStyleBackColor = true;
            this.buttonK.Click += new System.EventHandler(this.buttonK_Click);
            // 
            // buttonL
            // 
            this.buttonL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonL.Location = new System.Drawing.Point(602, 71);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(78, 50);
            this.buttonL.TabIndex = 16;
            this.buttonL.Text = "L";
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.buttonL_Click);
            // 
            // buttonA
            // 
            this.buttonA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonA.Location = new System.Drawing.Point(16, 71);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(78, 50);
            this.buttonA.TabIndex = 17;
            this.buttonA.Text = "A";
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
            // 
            // buttonS
            // 
            this.buttonS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonS.Location = new System.Drawing.Point(100, 71);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(78, 50);
            this.buttonS.TabIndex = 18;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
            // 
            // button_delete
            // 
            this.button_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete.Location = new System.Drawing.Point(16, 127);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(97, 50);
            this.button_delete.TabIndex = 19;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // buttonC
            // 
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC.Location = new System.Drawing.Point(254, 125);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(61, 50);
            this.buttonC.TabIndex = 20;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(321, 125);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(61, 50);
            this.button2.TabIndex = 21;
            this.button2.Text = "V";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonX
            // 
            this.buttonX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonX.Location = new System.Drawing.Point(187, 125);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(61, 50);
            this.buttonX.TabIndex = 22;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonB
            // 
            this.buttonB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonB.Location = new System.Drawing.Point(388, 125);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(61, 50);
            this.buttonB.TabIndex = 23;
            this.buttonB.Text = "B";
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.buttonB_Click);
            // 
            // buttonN
            // 
            this.buttonN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonN.Location = new System.Drawing.Point(455, 125);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(61, 50);
            this.buttonN.TabIndex = 24;
            this.buttonN.Text = "N";
            this.buttonN.UseVisualStyleBackColor = true;
            this.buttonN.Click += new System.EventHandler(this.buttonN_Click);
            // 
            // buttonZ
            // 
            this.buttonZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonZ.Location = new System.Drawing.Point(120, 125);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(61, 50);
            this.buttonZ.TabIndex = 25;
            this.buttonZ.Text = "Z";
            this.buttonZ.UseVisualStyleBackColor = true;
            this.buttonZ.Click += new System.EventHandler(this.buttonZ_Click);
            // 
            // buttonM
            // 
            this.buttonM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonM.Location = new System.Drawing.Point(522, 125);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(61, 50);
            this.buttonM.TabIndex = 26;
            this.buttonM.Text = "M";
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.buttonM_Click);
            // 
            // button_enter
            // 
            this.button_enter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_enter.Location = new System.Drawing.Point(589, 127);
            this.button_enter.Name = "button_enter";
            this.button_enter.Size = new System.Drawing.Size(91, 50);
            this.button_enter.TabIndex = 27;
            this.button_enter.Text = "Enter";
            this.button_enter.UseVisualStyleBackColor = true;
            this.button_enter.Click += new System.EventHandler(this.button_enter_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 481);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.box9_4);
            this.Controls.Add(this.box9_3);
            this.Controls.Add(this.box9_2);
            this.Controls.Add(this.box9_1);
            this.Controls.Add(this.box9_0);
            this.Controls.Add(this.box8_4);
            this.Controls.Add(this.box8_3);
            this.Controls.Add(this.box8_2);
            this.Controls.Add(this.box8_1);
            this.Controls.Add(this.box8_0);
            this.Controls.Add(this.box7_4);
            this.Controls.Add(this.box7_3);
            this.Controls.Add(this.box7_2);
            this.Controls.Add(this.box7_1);
            this.Controls.Add(this.box7_0);
            this.Controls.Add(this.box6_4);
            this.Controls.Add(this.box6_3);
            this.Controls.Add(this.box6_2);
            this.Controls.Add(this.box6_1);
            this.Controls.Add(this.box6_0);
            this.Controls.Add(this.box5_4);
            this.Controls.Add(this.box5_3);
            this.Controls.Add(this.box5_2);
            this.Controls.Add(this.box5_1);
            this.Controls.Add(this.box5_0);
            this.Controls.Add(this.box4_4);
            this.Controls.Add(this.box4_3);
            this.Controls.Add(this.box4_2);
            this.Controls.Add(this.box4_1);
            this.Controls.Add(this.box4_0);
            this.Controls.Add(this.box3_4);
            this.Controls.Add(this.box3_3);
            this.Controls.Add(this.box3_2);
            this.Controls.Add(this.box3_1);
            this.Controls.Add(this.box3_0);
            this.Controls.Add(this.box2_4);
            this.Controls.Add(this.box2_3);
            this.Controls.Add(this.box2_2);
            this.Controls.Add(this.box2_1);
            this.Controls.Add(this.box2_0);
            this.Controls.Add(this.box1_4);
            this.Controls.Add(this.box1_3);
            this.Controls.Add(this.box1_2);
            this.Controls.Add(this.box1_1);
            this.Controls.Add(this.box1_0);
            this.Controls.Add(this.box0_4);
            this.Controls.Add(this.box0_3);
            this.Controls.Add(this.box0_2);
            this.Controls.Add(this.box0_1);
            this.Controls.Add(this.box0_0);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox box0_0;
        private System.Windows.Forms.TextBox box0_1;
        private System.Windows.Forms.TextBox box0_2;
        private System.Windows.Forms.TextBox box0_3;
        private System.Windows.Forms.TextBox box0_4;
        private System.Windows.Forms.TextBox box1_0;
        private System.Windows.Forms.TextBox box1_1;
        private System.Windows.Forms.TextBox box1_2;
        private System.Windows.Forms.TextBox box1_3;
        private System.Windows.Forms.TextBox box1_4;
        private System.Windows.Forms.TextBox box2_4;
        private System.Windows.Forms.TextBox box2_3;
        private System.Windows.Forms.TextBox box2_2;
        private System.Windows.Forms.TextBox box2_1;
        private System.Windows.Forms.TextBox box2_0;
        private System.Windows.Forms.TextBox box3_4;
        private System.Windows.Forms.TextBox box3_3;
        private System.Windows.Forms.TextBox box3_2;
        private System.Windows.Forms.TextBox box3_1;
        private System.Windows.Forms.TextBox box3_0;
        private System.Windows.Forms.TextBox box4_4;
        private System.Windows.Forms.TextBox box4_3;
        private System.Windows.Forms.TextBox box4_2;
        private System.Windows.Forms.TextBox box4_1;
        private System.Windows.Forms.TextBox box4_0;
        private System.Windows.Forms.TextBox box5_4;
        private System.Windows.Forms.TextBox box5_3;
        private System.Windows.Forms.TextBox box5_2;
        private System.Windows.Forms.TextBox box5_1;
        private System.Windows.Forms.TextBox box5_0;
        private System.Windows.Forms.TextBox box6_4;
        private System.Windows.Forms.TextBox box6_3;
        private System.Windows.Forms.TextBox box6_2;
        private System.Windows.Forms.TextBox box6_1;
        private System.Windows.Forms.TextBox box6_0;
        private System.Windows.Forms.TextBox box7_4;
        private System.Windows.Forms.TextBox box7_3;
        private System.Windows.Forms.TextBox box7_2;
        private System.Windows.Forms.TextBox box7_1;
        private System.Windows.Forms.TextBox box7_0;
        private System.Windows.Forms.TextBox box8_4;
        private System.Windows.Forms.TextBox box8_3;
        private System.Windows.Forms.TextBox box8_2;
        private System.Windows.Forms.TextBox box8_1;
        private System.Windows.Forms.TextBox box8_0;
        private System.Windows.Forms.TextBox box9_4;
        private System.Windows.Forms.TextBox box9_3;
        private System.Windows.Forms.TextBox box9_2;
        private System.Windows.Forms.TextBox box9_1;
        private System.Windows.Forms.TextBox box9_0;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button_enter;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonZ;
    }
}